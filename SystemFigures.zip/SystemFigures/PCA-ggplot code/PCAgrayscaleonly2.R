#setwd("C:/Users/Jscales/Desktop/Lizard_perf/")
#setwd("~/Desktop/Dissertation/Rdata")

require(ggplot2)
require(ks)


# Multiple plot function
#
# ggplot objects can be passed in ..., or to plotlist (as a list of ggplot objects)
# - cols:   Number of columns in layout
# - layout: A matrix specifying the layout. If present, 'cols' is ignored.
#
# If the layout is something like matrix(c(1,2,3,3), nrow=2, byrow=TRUE),
# then plot 1 will go in the upper left, 2 will go in the upper right, and
# 3 will go all the way across the bottom.
#
multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  library(grid)

  # Make a list from the ... arguments and plotlist
  plots <- c(list(...), plotlist)

  numPlots = length(plots)

  # If layout is NULL, then use 'cols' to determine layout
  if (is.null(layout)) {
    # Make the panel
    # ncol: Number of columns of plots
    # nrow: Number of rows needed, calculated from # of cols
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                    ncol = cols, nrow = ceiling(numPlots/cols))
  }

 if (numPlots==1) {
    print(plots[[1]])

  } else {
    # Set up the page
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))

    # Make each plot, in the correct location
    for (i in 1:numPlots) {
      # Get the i,j matrix positions of the regions that contain this subplot
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))

      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}

dat<-read.csv("sppmeans.csv", header=T)
dat$accel<-dat$accel*100
dat$speed<-dat$speed*100
dat$dist<-dat$dist*100
dat<-dat[-1,]
dat<-dat[,-c(1,12,13)]

dat[,2:11]<-log(dat[,2:11]) # log transforms morph and performance data
attach(dat)


#######  PCA analysis  ##########


pc.dat<-dat[,1:5]

#pc.size<-size[,4:8]
#rownames(pc.size)<-c("ek", "us", "sg", "sm", "sv", "st", "so", "sp", "sj", "sc", "uo", "ug", "ps", "pm", "pc", "hm", "ct", "cd", "cc", "au", "at")
#pc.perf<-princomp(pc.size[,2:5], cor=T)
 
pc.perf<-princomp(pc.dat[,2:5], cor=T)
#summary(pc.perf)
#loadings(pc.perf)
#plot(pc.perf)
#biplot(pc.perf)

#
pcscores<-as.data.frame(pc.perf$scores)
rownames(pcscores)<-pc.dat$species
pcscores[,1]<-pcscores[,1]*-1
#pairs(pcscores[1:4], pch=21)

## makes groups for the pca plots
pcscores$pred<-c("sprint", "sprint", "sprint", "sprint", "sprint", "mixed", "cryptic","cryptic", "cryptic", "cryptic", "mixed", "mixed", "mixed", "mixed", "mixed", "mixed", "mixed", "mixed", "cryptic", "mixed", "mixed")

pcscores$forag<-c("active", "active", "sw", "sw", "sw", "active", "sw","ant", "ant", "ant", "sw", "sw", "sw", "sw", "sw", "sw", "sw", "sw", "sw", "sw", "sw")

pcscores$combo<-c("fstex", "fstex", "loex", "loex", "loex", "sloex", "loex","sloex", "sloex", "sloex", "loex", "loex", "loex", "loex", "loex", "loex", "loex", "loex", "loex", "loex", "loex")

pcscores$pred2r<-c("sprint", "sprint", "sprint", "sprint", "sprint", "mixed", "mixed","mixed", "mixed", "mixed", "mixed", "mixed", "mixed", "mixed", "mixed", "mixed", "mixed", "mixed", "mixed", "mixed", "mixed")

pcscores$pred<-as.factor(pcscores$pred)
pcscores$pred<-as.factor(pcscores$pred2r)
pcscores$forag<-as.factor(pcscores$forag)
pcscores$combo<-as.factor(pcscores$combo)

require(ks)


#### Plots PC components for pred escape with 3 regimes

fhat<-Hscv(pcscores[pcscores$pred=="sprint",1:2])
tt<-kde(pcscores[pcscores$pred=="sprint",1:2], H=fhat)
x <- rep(tt$eval.points[[1]], times=length(tt$eval.points[[1]]))
y <- rep(tt$eval.points[[2]], each=length(tt$eval.points[[2]]))
z <- as.vector(tt$estimate)
dat <- data.frame(x, y, z=z)

fhat<-Hscv(pcscores[pcscores$pred=="mixed",1:2])
tt<-kde(pcscores[pcscores$pred=="mixed",1:2], H=fhat)
x <- rep(tt$eval.points[[1]], times=length(tt$eval.points[[1]]))
y <- rep(tt$eval.points[[2]], each=length(tt$eval.points[[2]]))
z <- as.vector(tt$estimate)
dat2 <- data.frame(x, y, z=z)

p <- ggplot(data=pcscores, aes(Comp.1, Comp.2)) 

p1col <- p + theme_classic() + 
	labs(x="PC1 (Sprint)", y="PC2 (Exertion)") +
	scale_y_continuous(breaks=seq(-4,4,2)) +
	scale_x_continuous(breaks=seq(-4,4,2)) +
	coord_fixed(ratio=1, xlim=c(-3.5,4), ylim=c(-3,4)) +
	stat_contour(data=dat, geom="polygon", aes(x=x, y=y, z=z/max(z), fill=..level..), bins=4,  alpha=.15) +
	stat_contour(data=dat2, geom="polygon", aes(x=x, y=y, z=z/max(z), fill=..level..), bins=4, alpha=.15) +
	geom_point(data=pcscores[pcscores$pred=="sprint", 1:2], colour="red", size=5) +
	geom_point(data=pcscores[pcscores$pred=="mixed", 1:2], colour="blue", size=5) +
	theme(legend.position="none")
	


p1bw <- p + theme_classic() +
	labs(x="PC1 (Sprint)", y="PC2 (Exertion)") +
	scale_y_continuous(breaks=seq(-4,4,2)) +
	scale_x_continuous(breaks=seq(-4,4,2)) +
	coord_fixed(ratio=1, xlim=c(-3.5,4), ylim=c(-3,4)) +
	stat_contour(data=dat, geom="polygon", aes(x=x, y=y, z=z/max(z), fill=..level..), bins=10,  alpha=.15) +
	stat_contour(data=dat2, geom="polygon", aes(x=x, y=y, z=z/max(z), fill=..level..), bins=10, alpha=.15) +
	geom_point(data=pcscores[pcscores$pred=="sprint", 1:2], color="white", size=5) +
	geom_point(data=pcscores[pcscores$pred=="mixed", 1:2], color="black", size=5) +
	theme(legend.position="none")

p + geom_density2d() + stat_density2d(aes(fill=..level.., alpha=..level..), size=0.01, bins=16, geom='polygon') +
scale_fill_gradient(low="green", high="red") +
scale_alpha(range=c(0.00, 0.25), guide=FALSE) +
 theme(legend.position = "none", axis.title = element_blank(), text = element_text(size = 12))

ggplot(pcdat, aes(x=x, y=y), extent=normal) +
	labs(x="PC1 (Sprint)", y="PC2 (Exertion)") +
	stat_density2d(geom="tile", aes(fill=group, alpha=..density..), contour=FALSE) +
	scale_fill_manual(values=c("sprint"="#FF0000", "mixed"="#00FF00")) +
	geom_point(data=pcdat[pcdat$group=="sprint", 1:2], colour="blue", size=5) +
	geom_point(data=pcdat[pcdat$group=="mixed", 1:2], colour="red", size=5) +
	theme_minimal() +
	xlim(-4, 4) + ylim(-4, 5) +
	coord_cartesian(xlim=c(-3.5, 4), ylim=c(-3,4))

# ================== USED THIS ONE
pcdat <- pcscores[c("Comp.1", "Comp.2", "pred", "forag")]
names(pcdat) <- c("x", "y", "pred", "forag")

p3pred <- ggplot(pcdat, aes(x=x, y=y), extent=normal) +
	labs(x="PC1 (Sprint)", y="PC2 (Exertion)") +
	stat_density2d(geom="polygon", aes(fill=pred, color=pred, alpha=..level..), size=.5, contour=TRUE) +
	geom_point(data=pcdat[pcdat $pred=="sprint", 1:2], color="blue", size=4, pch=17) +
	geom_point(data= pcdat[pcdat $pred=="mixed", 1:2], color="red", size=4, pch=16) +
	theme_minimal() +
	xlim(-4, 4) + ylim(-4, 5) +
	coord_fixed(ratio=1, xlim=c(-4,4), ylim=c(-4,4)) +
	theme(legend.position="none")

p3forag <- ggplot(pcdat, aes(x=x, y=y), extent=normal) +
	labs(x="PC1 (Sprint)", y="PC2 (Exertion)") +
	stat_density2d(geom="polygon", aes(fill=forag, color=forag, alpha=..level..), size=.5, contour=TRUE) +
	geom_point(data=pcdat[pcdat$forag=="sw", 1:2], color="blue", size=4, pch=16) +
	geom_point(data= pcdat[pcdat$forag=="ant", 1:2], color="purple", size=4, pch=15) +
	geom_point(data= pcdat[pcdat$forag=="active", 1:2], color="red", size=4, pch=17) +
	theme_minimal() +
	xlim(-6, 6) + ylim(-4, 5) +
	coord_fixed(ratio=1, xlim=c(-4,4), ylim=c(-4,4)) +
	theme(legend.position="none")

multiplot(p3pred, p3forag, cols=2)


p4pred <- ggplot(pcdat, aes(x=x, y=y), extent=normal) +
	labs(x="PC1 (Sprint)", y="PC2 (Exertion)") +
	stat_density2d(geom="polygon", aes( fill=pred, color=pred, alpha=..level..), size=.2, contour=TRUE) +
	scale_fill_manual(values=c("sprint"="grey30", "mixed"="grey30")) +
	scale_color_manual(values=c("sprint"="grey30", "mixed"="grey30")) +
	geom_point(data=pcdat[pcdat$pred=="sprint", 1:2], colour="black", size=4, pch=17) +
	geom_point(data=pcdat[pcdat$pred=="mixed", 1:2], colour="white", size=4, pch=16) +
	theme_minimal() +
	xlim(-4, 4) + ylim(-4, 5) +
	coord_fixed(ratio=1, xlim=c(-4,4), ylim=c(-4,4)) +
	theme(legend.position="none")

p4forag <- ggplot(pcdat, aes(x=x, y=y), extent=normal) +
	labs(x="PC1 (Sprint)", y="PC2 (Exertion)") +
	stat_density2d(geom="polygon", aes(fill=forag, color=forag, alpha=..level..), size=.2, contour=TRUE) +
	scale_fill_manual(values=c("sw"="black", "ant"="black", "active"="black")) +
	scale_color_manual(values=c("sw"="black", "ant"="black", "active"="black")) +
	geom_point(data=pcdat[pcdat$forag=="sw", 1:2], color="white", size=4, pch=16) +
	geom_point(data= pcdat[pcdat$forag=="ant", 1:2], color="white", size=3, pch=15) +
	geom_point(data= pcdat[pcdat$forag=="active", 1:2], color="black", size=4, pch=17) +
	theme_minimal() +
	xlim(-6, 6) + ylim(-4, 5) +
	coord_fixed(ratio=1, xlim=c(-4,4), ylim=c(-4,4)) +
	theme(legend.position="none")

multiplot(p4pred, p4forag, cols=2)

# ================== USED THIS ONE END

ggplot(pcdat, aes(x=x, y=y)) +
	stat_density2d(geom="density2d", aes(color=group, alpha=..level..), size=4, contour=TRUE) +
	scale_fill_manual(values=c("sprint"="gray", "mixed"="gray")) +
	geom_point() +
	theme_minimal() +
	xlim(-3.5, 4) + ylim(-3, 4) +
	coord_cartesian(xlim=c(-3.5, 4), ylim=c(-3,4))


ggplot(rbind(data.frame(data2, group="a"), data.frame(data, group="b")), aes(x=x,y=y)) + 
	stat_density2d(geom="tile", aes(fill = group, alpha=..density..), contour=FALSE) + 
	scale_fill_manual(values=c("b"="#FF0000", "a"="#00FF00")) + 
	geom_point() + 
	theme_minimal() + 
	xlim(-3.3, 3.3) + ylim(-3.3, 3.3) + 
	coord_cartesian(xlim = c(-3.2, 3.2), ylim = c(-3.2, 3.2))

ggplot(rbind(data.frame(data, group="a"), data.frame(data2, group="b")), 
       aes(x=x,y=y)) + 
  stat_density2d(geom="density2d", aes(color = group,alpha=..level..),
                 size=2,
                 contour=TRUE) + 
  #scale_color_manual(values=c("a"="#FF0000", "b"="#00FF00")) +
  geom_point() +
  theme_minimal() +
  xlim(-3.3, 3.3) + ylim(-3.3, 3.3) +
  coord_cartesian(xlim = c(-3.2, 3.2), ylim = c(-3.2, 3.2))

ggplot(rbind(data.frame(data, group="a"), data.frame(data2, group="b")), aes(x=x,y=y)) + 
  stat_density2d(geom="tile", aes(fill = group, alpha=..density..), contour=FALSE) + 
  scale_fill_manual(values=c("a"="#FF0000", "b"="#00FF00")) +
  geom_point() +
  theme_minimal() +
  xlim(-3.3, 3.3) + ylim(-3.3, 3.3) +
  coord_cartesian(xlim = c(-3.2, 3.2), ylim = c(-3.2, 3.2))
  
pcdat <- pcscores[c("Comp.1", "Comp.2", "pred")]
names(pcdat) <- c("x", "y", "group")

ggplot(pcdat, aes(x=x,y=y)) + 
  stat_density2d(geom="tile", aes(fill = group, alpha=..density..), contour=FALSE) + 
  scale_fill_manual(values=c("sprint"="#FF0000", "mixed"="#00FF00")) +
  geom_point() +
  theme_minimal() +
  xlim(-3.5, 4) + ylim(-3, 4) +
  coord_cartesian(xlim = c(-3.5, 4), ylim = c(-3, 4))


data = read.table(text="P1 -1 0 4\nP2 0 0 2\nP3 2 1 8\nP4 -2 -2 6\nP5 0.5 2 12")
data2 = read.table(text="Q1 1 1 3\nQ2 1 -1 2\nQ3 -1 1 8")
colnames(data) = c("name","x","y","score")
colnames(data2) = c("name","x","y","score")


## Plots PC components by foraging mode

fhat<-Hscv(pcscores[pcscores$forag=="sw",1:2])
tt<-kde(pcscores[pcscores$forag=="sw",1:2], H=fhat)
x <- rep(tt$eval.points[[1]], times=length(tt$eval.points[[1]]))
y <- rep(tt$eval.points[[2]], each=length(tt$eval.points[[2]]))
z <- as.vector(tt$estimate)
dat <- data.frame(x, y, z=z)

fhat<-Hscv(pcscores[pcscores$forag=="ant",1:2])
tt<-kde(pcscores[pcscores$forag=="ant",1:2], H=fhat)
x <- rep(tt$eval.points[[1]], times=length(tt$eval.points[[1]]))
y <- rep(tt$eval.points[[2]], each=length(tt$eval.points[[2]]))
z <- as.vector(tt$estimate)
dat2 <- data.frame(x, y, z=z)

fhat<-Hscv(pcscores[pcscores$forag=="active",1:2])
tt<-kde(pcscores[pcscores$forag=="active",1:2], H=fhat)
x <- rep(tt$eval.points[[1]], times=length(tt$eval.points[[1]]))
y <- rep(tt$eval.points[[2]], each=length(tt$eval.points[[2]]))
z <- as.vector(tt$estimate)
dat3 <- data.frame(x, y, z=z)

p <- ggplot(data=pcscores, aes(Comp.1, Comp.2)) 


p2col <- p + theme_classic() +
	labs(x="PC1 (Sprint)", y="PC2 (Exertion)") +
	scale_y_continuous(breaks=seq(-4,4,2)) +
	scale_x_continuous(breaks=seq(-4,4,2)) +
	coord_fixed(ratio=1, xlim=c(-3.5,4), ylim=c(-3,4)) +
	stat_contour(data=dat, geom="polygon", aes(x=x, y=y, z=z/max(z), fill=..level..), bins=4,  alpha=.15) +
	stat_contour(data=dat2, geom="polygon", aes(x=x, y=y, z=z/max(z), fill=..level..), bins=4, alpha=.15) +
	stat_contour(data=dat3, geom="polygon", aes(x=x, y=y, z=z/max(z), fill=..level..), bins=4, alpha=.15) +
	geom_point(data=pcscores[pcscores$forag=="sw", 1:2], colour="orange", size=5) +
	geom_point(data=pcscores[pcscores$forag=="ant", 1:2], colour="purple", size=5) +
	geom_point(data=pcscores[pcscores$forag=="active", 1:2], colour="green", size=5) +
	theme(legend.position="none")

p2bw <- p + theme_classic() +
	labs(x="PC1 (Sprint)", y="PC2 (Exertion)") +
	scale_y_continuous(breaks=seq(-4,4,2)) +
	scale_x_continuous(breaks=seq(-4,4,2)) +
	coord_fixed(ratio=1, xlim=c(-3.5,4), ylim=c(-3,4)) +
	stat_contour(data=dat, geom="polygon", aes(x=x, y=y, z=z/max(z), fill=..level..), bins=4,  alpha=.15) +
	stat_contour(data=dat2, geom="polygon", aes(x=x, y=y, z=z/max(z), fill=..level..), bins=4, alpha=.15) +
	stat_contour(data=dat3, geom="polygon", aes(x=x, y=y, z=z/max(z), fill=..level..), bins=4, alpha=.15) +
	geom_point(data=pcscores[pcscores$forag=="sw", 1:2], colour="black", size=5) +
	geom_point(data=pcscores[pcscores$forag=="ant", 1:2], colour="grey50", size=5) +
	geom_point(data=pcscores[pcscores$forag=="active", 1:2], colour="white", size=5) +
	theme(legend.position="none")



multiplot(p1bw, p2bw, cols=2)
quartz()
multiplot(p1col, p2col, cols=2)

