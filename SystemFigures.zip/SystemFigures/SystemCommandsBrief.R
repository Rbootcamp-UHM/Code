### System Commands - very brief
### anything you can run from the terminal you can run from R using system()

## check which files are in your current working directory

system("ls" )

## intern=TRUE returns results to console

system("ls", intern=TRUE )

## on a mac, the PDF application is preview. Open all pdfs in working directory

system("open -a preview *.pdf")
system("open -a preview ../*.pdf")  # opens all pdfs in parent directory

## basic syntax is system( command ) where command is the character string you 
## would type in terminal to run your application or other command. This will be
## specific to your operating system. On a mac it will be UNIX commands. On a PC
## it will be DOS-like commands

## Running clustalw with UNIX commands (must have clustalw installed) and assuming 
## there is a dna file in fasta format called foo.fasta

## you may have to set up the path to clustalw in your UNIX shell.
## Add binary path to environment. For example, in a bash console, edit the .bashrc file and add the following:
## export PATH=/path/to/clustalw/binary:$PATH

system("clustalw -align -type=dna -infile=foo.fasta > /dev/null")

## Otherwise you will have to provide the path
## for example:

# system("Path_to_clustalw/clustalw -align -type=dna -infile=foo.fasta > /dev/null")

