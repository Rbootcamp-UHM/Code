makeTransparent<-function(someColor, alpha=1)
{
  newColor<-col2rgb(someColor)
  apply(newColor, 2, function(curcoldata){rgb(red=curcoldata[1], green=curcoldata[2],
    blue=curcoldata[3],alpha=alpha*255, maxColorValue=255)})
}


## dat is a dataframe that contains a summary of all of the response counts per category


females <- read.csv("reflectancefemale.csv")
names(males) <- names(females)<- c("Wavelength", "mean", "SE", "X", "N", "median")

beads <- read.csv("reflectancebeads.csv")
lambda <- beads[[1]]
red <- rowMeans(beads[3:5])
brown <- rowMeans(beads[6:8])
black <- beads[[9]]
white <- rowMeans(beads[10:12])
green <- rowMeans(beads[13:15])
yellow <- rowMeans(beads[16:18])

plot(x=lambda, y=red, xlim=c(300,700), ylim=c(0,70), type="n", ylab="% Reflectance", xlab="Wavelength (nm)")
lines(lambda, red, col="red", lwd=5)
lines(lambda, brown, col="brown", lwd=5)
lines(lambda, black, col="black", lwd=5)
lines(lambda, green, col="green", lwd=5)
lines(lambda, yellow, col="yellow", lwd=5)
lines(lambda, white, col="black", lwd=5, lty=3)

with(males, lines(Wavelength, mean, col="red", lty="longdash", lwd=4))
with(females, lines(Wavelength, mean, col="brown", lty="longdash", lwd=4))

p<-ggplot(data=data, aes(x=interval, y=OR, colour=Drug)) + geom_point() + geom_line()
p<-p+geom_ribbon(aes(ymin=data$lower, ymax=data$upper), linetype=2, alpha=0.1)

quartz()
require(ggplot2)
dat <- males
p <- ggplot(data= males, aes(x=Wavelength, y=mean)) + geom_point(color="red") + geom_line(color="red")+geom_ribbon(data=males, aes(ymin=mean-SE, ymax=mean+SE), color="red", linetype=2, alpha=.1) + ylim(0,70)
dat <- females
p <- p+ geom_point(data= females, aes(x=Wavelength, y=mean, color="brown3")) + geom_line(color="brown3")+geom_ribbon(data=females, aes(ymin=mean-SE, ymax=mean+SE), color="brown3", linetype=2, alpha=.1)
p + scale_color_manual(values=c("#CC6666", "#9999CC"))



dat <- males
males$X<- "male"
females$X <- "female"
dat <- rbind(males, females)
dat$sex <- factor(dat$X)

p <- ggplot(data= dat, aes(x=Wavelength, y=mean, color=sex)) + geom_point() + geom_line()+geom_ribbon(data=dat, aes(ymin=mean-SE, ymax=mean+SE), linetype=2, alpha=.1) + ylim(0,70) 
p <- p + scale_color_manual(values=c("brown", "red")) + ylab("% Reflectance")
p+ theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(), panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))
